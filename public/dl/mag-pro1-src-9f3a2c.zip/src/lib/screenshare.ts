// WebRTC screen sharing with database-backed, admin-authorized signaling.
// Host = employee (shares screen), Viewer = admin (watches inside the panel).

import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";

export const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
    { urls: "stun:stun.cloudflare.com:3478" },
  ],
  bundlePolicy: "max-bundle",
  rtcpMuxPolicy: "require",
  iceCandidatePoolSize: 4,
  iceTransportPolicy: "all",
};

// خوادم TURN تُجلب من الخادم (بيانات دخول مؤقتة) وتُحدَّث داخل RTC_CONFIG نفسه.
// بدون TURN تفشل شبكات NAT الصعبة/الجيل الرابع فتبقى شاشة الموظف «جاري الاتصال».
let iceWarmed = 0;
export async function warmIceServers(force = false): Promise<void> {
  if (!force && Date.now() - iceWarmed < 2 * 60_000) return;
  try {
    const res = await fetch("/api/public/ice-servers", { cache: "no-store" });
    if (!res.ok) return;
    const json = (await res.json()) as { iceServers?: RTCIceServer[] };
    if (Array.isArray(json.iceServers) && json.iceServers.length) {
      RTC_CONFIG.iceServers = json.iceServers;
      // اترك WebRTC يختار أسرع مسار صالح. فرض TURN كان يمنع الاتصال بالكامل
      // عند انتهاء بياناته المؤقتة أو تعثر خادمه، رغم توفر مسار مباشر سليم.
      RTC_CONFIG.iceTransportPolicy = "all";
      iceWarmed = Date.now();
    }
  } catch {
    /* نكمل بإعدادات STUN الافتراضية */
  }
}
if (typeof window !== "undefined") void warmIceServers();



export type Signal =
  | { type: "join"; viewer?: string }
  | { type: "offer"; sdp: RTCSessionDescriptionInit; to?: string }
  | { type: "answer"; sdp: RTCSessionDescriptionInit; viewer?: string }
  | { type: "ice"; from: "host" | "viewer"; candidate: RTCIceCandidateInit; viewer?: string; to?: string }
  | { type: "bye"; viewer?: string };

export function makeViewerId(): string {
  return (
    globalThis.crypto?.randomUUID?.().slice(0, 12) ??
    Math.random().toString(36).slice(2, 14)
  );
}


export function openSignaling(
  code: string,
  onSignal: (s: Signal) => void,
  opts?: { raw?: boolean; viewerId?: string },
) {
  const deviceId = opts?.raw ? code : code.trim().toUpperCase();
  const seen = new Set<string>();
  const emit = (id: string | undefined, payload: Signal | undefined) => {
    if (!payload) return;
    if (id) {
      if (seen.has(id)) return;
      seen.add(id);
      if (seen.size > 400) seen.clear();
    }
    onSignal(payload);
  };

  const channel = supabase
    .channel(`admin-screenshare-${makeViewerId()}`)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "screenshare_signals",
        filter: `device_id=eq.${deviceId}`,
      },
      ({ new: row }) => {
        const record = row as { id?: string; sender?: string; viewer_id?: string; payload?: Signal };
        if (record.sender !== "host") return;
        if (opts?.viewerId && record.viewer_id && record.viewer_id !== opts.viewerId) return;
        burstUntil = Date.now() + 8_000;
        emit(record.id, record.payload);
      },
    );
  // Realtime مجرد مسار سريع، وليس شرطاً لبدء الاتصال. عند فتح شاشات كثيرة
  // قد يتأخر اشتراك بعض القنوات أو يصل TIMED_OUT، بينما إدخال/قراءة الإشارات
  // من الجدول يظل يعمل. ربط send() بالاشتراك كان يجعل بعض الأجهزة فقط تظل
  // على «جاري الاتصال» إلى الأبد بدون أن يصلها join أصلاً.
  const ready = new Promise<void>((resolve) => {
    const fallback = setTimeout(resolve, 1200);
    channel.subscribe((status) => {
      if (status === "SUBSCRIBED") {
        clearTimeout(fallback);
        resolve();
      }
      else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
        clearTimeout(fallback);
        resolve();
      }
    });
  });

  // احتياطي: استعلام دوري مباشر — لا نعتمد فقط على الزمن الحقيقي.
  // مع وجود عدة أجهزة موظفين قد تتأخر رسائل الزمن الحقيقي فتبقى بعض
  // الشاشات في «جاري الاتصال…» بلا سبب. هذا الاستعلام يضمن وصول العرض.
  let polling = false;
  const poll = async () => {
    if (polling) return;
    polling = true;
    try {
      let q = supabase
        .from("screenshare_signals")
        .select("id,viewer_id,payload")
        .eq("device_id", deviceId)
        .eq("sender", "host")
        .order("created_at", { ascending: false })
        // نستوعب رشقات offer/answer/ICE على الشبكات الضعيفة؛ حد 30 كان قد
        // يُسقط الإجابة من نافذة الاستعلام قبل وصولها ويترك الشاشة معلقة.
        .limit(150);
      if (opts?.viewerId) q = q.eq("viewer_id", opts.viewerId);
      const { data } = await q;
      for (const row of [...(data ?? [])].reverse()) {
        emit((row as any).id as string, (row as any).payload as Signal);
      }
    } catch {
      /* تجاهل */
    } finally {
      polling = false;
    }
  };
  // دورة تكيّفية: أثناء المصافحة (أو بعد إرسال إشارة) نستعلم كل ~180ms حتى
  // تصل إشارة المضيف فوراً، ثم نهدأ إلى ~900ms لتخفيف الحمل على الخادم.
  let burstUntil = Date.now() + 15_000;
  let pollTimer: ReturnType<typeof setTimeout> | null = null;
  let closed = false;
  const schedule = () => {
    if (closed) return;
    const fast = Date.now() < burstUntil;
    pollTimer = setTimeout(async () => {
      await poll();
      schedule();
    }, fast ? 180 : 900);
  };
  void poll();
  schedule();

  return {
    ready,
    send: async (s: Signal) => {
      const viewerId = "viewer" in s ? s.viewer : "to" in s ? s.to : undefined;
      if (!viewerId) throw new Error("Missing viewer identity");
      burstUntil = Date.now() + 15_000;
      const { error } = await supabase.from("screenshare_signals").insert({
        device_id: deviceId,
        viewer_id: viewerId,
        sender: "viewer",
        payload: s as unknown as Json,
      });
      if (error) throw error;
    },
    close: () => {
      closed = true;
      if (pollTimer) clearTimeout(pollTimer);
      supabase.removeChannel(channel);
    },
  };
}

