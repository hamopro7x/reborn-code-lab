import { useNavigate } from "@tanstack/react-router";
import { useCurrency } from "@/lib/currency-context";
import { convertFromEgp, formatPrice, computeDiscountedPrice } from "@/lib/format";
import { Heart, ShoppingCart, ShieldCheck } from "lucide-react";
import { useCart } from "@/lib/cart";
import { useFavorites } from "@/lib/favorites";
import { toast } from "sonner";

export function ProductCard({ p }: { p: any }) {
  const { currency, rates } = useCurrency();
  const navigate = useNavigate();
  const { add } = useCart();
  const { isFavorite, toggle } = useFavorites();
  const rate = rates[currency.code] ?? 1;
  const price = computeDiscountedPrice(p.base_price_egp, p.discount_percent ?? 0);
  const localized = convertFromEgp(price, rate, currency.code);
  const original = convertFromEgp(p.base_price_egp, rate, currency.code);
  const hasDiscount = (p.discount_percent ?? 0) > 0;
  const fav = isFavorite(p.id);
  const warranty = p.warranty_text?.trim() || (p.warranty_days > 0 ? `ضمان ${p.warranty_days} يوم` : null);

  const onAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      add({
        productId: p.id,
        slug: p.slug,
        name: p.name,
        image: p.main_image,
        basePriceEgp: Number(p.base_price_egp),
        discountPercent: Number(p.discount_percent ?? 0),
        warrantyDays: Number(p.warranty_days ?? 0),
      });
    } catch {
      toast.error("تعذر إضافة المنتج إلى السلة");
      return;
    }
    toast.success("تمت الإضافة إلى السلة");
    navigate({ to: "/cart" });
  };

  const onFav = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const added = toggle(p.id);
    toast.success(added ? "تمت الإضافة إلى المفضلة" : "تمت الإزالة من المفضلة");
  };

  return (
    <div
      className="group rounded-xl border border-border bg-card text-card-foreground overflow-hidden flex flex-col transition-colors duration-150 hover:border-primary md:w-[6cm] md:h-[7cm]"
    >
      <div className="relative aspect-[4/3] md:aspect-auto md:flex-1 md:min-h-0 bg-muted overflow-hidden">
        {p.main_image ? (
          <img
            src={p.main_image}
            alt={p.name}
            width={600}
            height={600}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-xs text-muted-foreground">
            {p.name}
          </div>
        )}
      </div>

      <div className="px-3 py-1.5 md:px-2.5 md:py-1.5 flex flex-col gap-0.5 md:gap-1 border-t border-border shrink-0">
        <h3 className="text-xs md:text-sm font-bold line-clamp-1 min-w-0 leading-tight">
          {p.name}
        </h3>
        {warranty && (
          <div className="flex items-center gap-1 text-[10px] md:text-[11px] text-muted-foreground line-clamp-1 min-w-0 leading-tight">
            <ShieldCheck className="size-3 md:size-3.5 shrink-0" />
            <span>{warranty}</span>
          </div>
        )}


        <div className="flex items-center justify-between gap-2 min-w-0" dir="ltr">
          <div className="flex items-center gap-2 md:gap-1.5 shrink-0">
            <button
              type="button"
              onClick={onFav}
              aria-label={fav ? `إزالة ${p.name} من المفضلة` : `أضف ${p.name} إلى المفضلة`}
              className={fav ? "text-primary" : "text-muted-foreground hover:text-primary transition-colors duration-150"}
            >
              <Heart className="size-4 md:size-4" fill={fav ? "currentColor" : "none"} />
            </button>
            <button
              type="button"
              onClick={onAdd}
              aria-label={`أضف ${p.name} إلى السلة`}
              className="inline-flex items-center gap-1 bg-black text-white rounded-md px-2 py-1 md:px-2 md:py-1 text-xs md:text-xs font-medium hover:bg-black/80 transition-colors shrink-0"
            >
              <ShoppingCart className="size-3.5 md:size-3.5 text-blue-400" />
              <span>اطلب الآن</span>
            </button>
          </div>

          <div className="flex items-center justify-end gap-1.5 min-w-0 shrink-0 leading-tight">
            {hasDiscount && (
              <span className="text-[10px] md:text-xs text-muted-foreground line-through">
                {formatPrice(original, currency)}
              </span>
            )}
            <span className="text-sm md:text-base font-black text-card-foreground">
              {formatPrice(localized, currency)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
